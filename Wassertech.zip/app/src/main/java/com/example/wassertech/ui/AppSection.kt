package com.example.wassertech.ui

enum class AppSection {
    Clients,
    Empty
}
