// removed extension; method is now inside HierarchyViewModel
