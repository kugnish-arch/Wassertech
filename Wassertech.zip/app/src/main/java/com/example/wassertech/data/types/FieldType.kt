package com.example.wassertech.data.types

enum class FieldType {
    CHECKBOX,
    NUMBER,
    TEXT
}