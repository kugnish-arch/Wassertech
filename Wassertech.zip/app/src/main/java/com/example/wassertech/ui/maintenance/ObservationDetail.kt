
package com.example.wassertech.ui.maintenance

data class ObservationDetail(
    val componentId: String,
    val componentName: String,
    val fieldKey: String,
    val valueText: String
)
