package com.example.wassertech.data.types

enum class Severity {
    LOW,
    MEDIUM,
    HIGH
}