package com.example.wassertech.viewmodel

typealias ChecklistUiField = com.example.wassertech.ui.maintenance.ChecklistUiField