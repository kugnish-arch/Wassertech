package com.example.wassertech.viewmodel.compat

typealias FieldUi = com.example.wassertech.viewmodel.TemplatesViewModel.UiField
