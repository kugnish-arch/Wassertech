plugins {
    // empty — all plugins are in :app
}



